<?php

echo 'ok';